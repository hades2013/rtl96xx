﻿/* 
	Copyright 2013-2020, 	
	All rights reserved.
	Author: Einsn Liu (einsn@qq.com)
	Date: 2013-03-25 
*/

var config_default_value = " ";

function config_item(cfg, index)
{
		var s = cfg.split(';');
		if (s.length > index){
			return s[index];
		}
		return config_default_value;			
}
/*
CNU104-H;5;0;4,3,2,1,0
*/

function dev_alias(cfg)
{
	if (cfg){
		return config_item(cfg, 0);
	}
	return config_default_value; 			
}

function dev_ifnum(cfg)
{
	if (cfg){
		return config_item(cfg, 1);
	}
	return config_default_value; 			
}

function dev_baseid(cfg)
{
	if (cfg){
		return config_item(cfg, 2);
	}
	return 0; 			
}

function dev_devid(cfg)
{
	if (cfg){
		return config_item(cfg, 3);
	}
	return 0; 			
}

function dev_tmplid(cfg)
{
	if (cfg){
		return config_item(cfg, 4);
	}
	return 0; 			
}

/*
40:C2:45:10:DB:D7;1;1;acc;user10DBD7;
*/

function user_mac(cfg)
{
	if (cfg){
		return config_item(cfg, 0).toUpperCase();
	}
	return config_default_value; 			
}

function user_tmplid(cfg)
{
	if (cfg){
		return config_item(cfg, 1);
	}
	return config_default_value; 			
}

function user_devid(cfg)
{
	if (cfg){
		return config_item(cfg, 2);
	}
	return config_default_value; 			
}

function user_auth(cfg)
{
	if (cfg){
		return config_item(cfg, 3);
	}
	return config_default_value; 			
}

function user_name(cfg)
{
	if (cfg){
		return config_item(cfg, 4);
	}
	return config_default_value; 			
}

function user_desc(cfg)
{
	if (cfg){
		return config_item(cfg, 5);
	}
	return config_default_value; 			
}

function user_index(cfg)
{
	if (cfg){
		return config_item(cfg, 6);
	}
	return config_default_value; 			
}

function user_search(list, filter)
{
	var show=new Array();
	var re=/^\s*$/;
	var fact=filter.toUpperCase();
	if (re.test(filter)) return list;
	for (var i=0; i < list.length; i ++){
		var m = user_mac(list[i]).toUpperCase();
		if (m.indexOf(fact) != -1){
			show[show.length] = list[i];
			continue;
		}
		var m1 = m.split(':');
		var m2 = '';
		for (var j= 0; j < m1.length; j ++){
			m2 += m1[j];	
		}
		if (m2.indexOf(fact) != -1){
			show[show.length] = list[i];
			continue;
		}
		m = user_name(list[i]).toUpperCase();
		if (m.indexOf(fact) != -1){
			show[show.length] = list[i];
			continue;
		}
		m = user_desc(list[i]).toUpperCase();
		if (m.indexOf(fact) != -1){
			show[show.length] = list[i];
			continue;
		}			
	}
	return show;	
}

/*
'6;1;Default222;Default template for CNU104-H'
*/

function tmpl_index(cfg)
{
	if (cfg){
		return config_item(cfg, 0);
	}
	return config_default_value; 			
}

function tmpl_devid(cfg)
{
	if (cfg){
		return config_item(cfg, 1);
	}
	return config_default_value; 			
}

function tmpl_name(cfg)
{
	if (cfg){
		return config_item(cfg, 2);
	}
	return config_default_value; 			
}

function tmpl_desc(cfg)
{
	if (cfg){
		return config_item(cfg, 3);
	}
	return config_default_value; 			
}

function tmpl_vlans(cfg)
{
	if (cfg){
		return config_item(cfg, 4);
	}
	return config_default_value; 				
}

/*
var tmpl_misc='0;0;off;0';
*/

function tmpl_uprate(cfg)
{
	if (cfg){
		return config_item(cfg, 0);
	}
	return config_default_value; 			
}

function tmpl_downrate(cfg)
{
	if (cfg){
		return config_item(cfg, 1);
	}
	return config_default_value; 			
}

function tmpl_bcast(cfg)
{
	if (cfg){
		return ((parseInt(config_item(cfg, 2)) & 0x3ff) > 0) ? "on" : "off";
	}
	return config_default_value; 			
}

function tmpl_mcast(cfg)
{
	if (cfg){
		return (((parseInt(config_item(cfg, 2)) >> 10) & 0x3ff) > 0) ? "on" : "off";
	}
	return config_default_value; 			
}

function tmpl_ucast(cfg)
{
	if (cfg){
		return (((parseInt(config_item(cfg, 2)) >> 20) & 0x3ff) > 0) ? "on" : "off";
	}
	return config_default_value; 			
}

function tmpl_bcast_value(cfg)
{
        var bcast, mcast, ucast;
	if (cfg){
                bcast = (parseInt(config_item(cfg, 2)) & 0x3ff);
		mcast = ((parseInt(config_item(cfg, 2)) >> 10) & 0x3ff);
                ucast = ((parseInt(config_item(cfg, 2)) >> 20) & 0x3ff); 
                if (bcast > 0){
                    return bcast;
                }
                if (mcast > 0){
                    return mcast;
                }
                if (ucast > 0){
                    return ucast;
                }
                return 0;
	}
	return config_default_value; 			
}

function tmpl_mcast_value(cfg)
{
	if (cfg){
		return ((parseInt(config_item(cfg, 2)) >> 10) & 0x3ff)
	}
	return config_default_value; 			
}

function tmpl_ucast_value(cfg)
{
	if (cfg){
		return ((parseInt(config_item(cfg, 2)) >> 20) & 0x3ff)
	}
	return config_default_value; 			
}

function tmpl_maclimit(cfg)
{
	if (cfg){
		return config_item(cfg, 3);
	}
	return config_default_value; 			
}

function tmpl_vlan_transparent(cfg)
{
	if (cfg){
		return config_item(cfg, 4);
	}
	return config_default_value; 			
}

function tmpl_igmp_snooping(cfg)
{
	if (cfg){
		return config_item(cfg, 5);
	}
	return config_default_value; 			
}

/*
"1;auto;auto;0;off;0;0;off;1;ena",
*/

function tmpl_portid(cfg)
{
	if (cfg){
		return config_item(cfg, 0);
	}
	return config_default_value; 			
}

function tmpl_speed(cfg)
{
	if (cfg){
		return config_item(cfg, 1);
	}
	return config_default_value; 			
}

function tmpl_duplex(cfg)
{
	if (cfg){
		return config_item(cfg, 2);
	}
	return config_default_value; 			
}

function tmpl_priority(cfg)
{
	if (cfg){
		return config_item(cfg, 3);
	}
	return config_default_value; 			
}

function tmpl_flowctrl(cfg)
{
	if (cfg){
		return config_item(cfg, 4);
	}
	return config_default_value; 			
}

function tmpl_inrate(cfg)
{
	if (cfg){
		return config_item(cfg, 5);
	}
	return config_default_value; 			
}

function tmpl_outrate(cfg)
{
	if (cfg){
		return config_item(cfg, 6);
	}
	return config_default_value; 			
}


function tmpl_vlantag(cfg)
{
	if (cfg){
		return config_item(cfg, 7);
	}
	return config_default_value; 			
}

function tmpl_pvid(cfg)
{
	if (cfg){
		return config_item(cfg, 8);
	}
	return config_default_value; 			
}

function tmpl_enable(cfg)
{
	if (cfg){
		return config_item(cfg, 9);
	}
	return config_default_value; 			
}



function tmpl_search(list, filter)
{
	var show=new Array();
	var re=/^\s*$/;
	var fact=filter.toUpperCase();
	if (re.test(filter)) return list;
	for (var i=0; i < list.length; i ++){
		var m = tmpl_name(list[i]).toUpperCase();
		if (m.indexOf(fact) != -1){
			show[show.length] = list[i];
			continue;
		}
		m = tmpl_desc(list[i]).toUpperCase();
		if (m.indexOf(fact) != -1){
			show[show.length] = list[i];
			continue;
		}
	}
	return show;	
}


/* on line cnu info */
/*'2;1;40:C2:45:10:DB:D7;2;0;0;CNU104-H;1;any;;1;1;3507;60;FWVER'*/


function cnu_clt_id(cfg)
{
	if (cfg){
		return config_item(cfg, 0);
	}
	return config_default_value; 			
}


function cnu_index(cfg)
{
	if (cfg){
		return config_item(cfg, 1);
	}
	return config_default_value; 			
}

function cnu_mac(cfg)
{
	if (cfg){
		return config_item(cfg, 2).toUpperCase();
	}
	return config_default_value; 			
}

function cnu_tei(cfg)
{
	if (cfg){
		return config_item(cfg, 3);
	}
	return config_default_value; 			
}

function cnu_avgtx(cfg)
{
	if (cfg){
		return config_item(cfg, 4);
	}
	return config_default_value; 			
}

function cnu_avgrx(cfg)
{
	if (cfg){
		return config_item(cfg, 5);
	}
	return config_default_value; 			
}


function cnu_alias(cfg)
{
	if (cfg){
		return config_item(cfg, 6);
	}
	return config_default_value; 			
}


function cnu_link(cfg)
{
	if (cfg){
		switch(parseInt(config_item(cfg, 7), 10))
		{
			case 1:
			return 'up';
			case 2:
			return 'down';
			case 3:
			return 'loop';
			case 4:
			return 'deny';	
		}
		return 'unknown';
	}
	return config_default_value; 			
}


function cnu_auth(cfg)
{
	if (cfg){
		switch(parseInt(config_item(cfg, 8), 10))
		{
			case 1:
			return 'anon_accept';
			case 2:
			return 'accept';
			case 3:
			return 'deny';
			case 4:
			return 'anon_deny';	
		}		
		return config_item(cfg, 8);
	}
	return config_default_value; 			
}

function cnu_username(cfg)
{
	if (cfg){
		return config_item(cfg, 9);
	}
	return config_default_value; 			
}

function cnu_devid(cfg)
{
	if (cfg){
		return config_item(cfg, 10);
	}
	return config_default_value; 			
}

function cnu_tmplid(cfg)
{
	if (cfg){
		return config_item(cfg, 11);
	}
	return config_default_value; 			
}

function cnu_uptime(cfg)
{
	if (cfg){
		return config_item(cfg, 12);
	}
	return config_default_value; 			
}

function cnu_attenuation(cfg)
{
	if (cfg){
		return config_item(cfg, 13);
	}
	return config_default_value; 			
}

function cnu_version(cfg)
{
	if (cfg){
		return config_item(cfg, 14);
	}
	return config_default_value; 			
}

function cnu_portnum(cfg)
{
	if (cfg){
		return config_item(cfg, 15);
	}
	return config_default_value; 			
}

function cnu_search(list, filter)
{
	var show=new Array();
	var re=/^\s*$/;
	var fact=filter.toUpperCase();
	if (re.test(filter)) return list;
	for (var i=0; i < list.length; i ++){
		var m = cnu_mac(list[i]).toUpperCase();
		if (m.indexOf(fact) != -1){
			show[show.length] = list[i];
			continue;
		}
		var m1 = m.split(':');
		var m2 = '';
		for (var j= 0; j < m1.length; j ++){
			m2 += m1[j];	
		}
		if (m2.indexOf(fact) != -1){
			show[show.length] = list[i];
			continue;
		}
		m = cnu_username(list[i]).toUpperCase();
		if (m.indexOf(fact) != -1){
			show[show.length] = list[i];
			continue;
		}
	}
	return show;	
}

/*
'1;40:C2:45:00:77:F6;CLT502;2;1;1;3;INT7400-MAC-7-0-7001-14-31-20110706-FINAL-A'
*/

function clt_mac(cfg)
{
	if (cfg){
		return config_item(cfg, 1);
	}
	return "Unknown"; 	
}

function clt_model(cfg)
{
	if (cfg){
		return config_item(cfg, 2);
	}
	return "Unknown"; 
}

function clt_location(cfg)
{
	if (cfg){
		return config_item(cfg, 4);
	}
	return "Unknown"; 
}

function clt_snid(cfg)
{
	if (cfg){
		return config_item(cfg, 5);
	}
	return "1"; 
}

function clt_version(cfg)
{
	if (cfg){
		return config_item(cfg, 7);
	}
	return 'Unknown';
}

function clt_status(cfg)
{
	if (cfg){
		return config_item(cfg, 3);
	}
	return 'Unknown';
}


/* n_service_list */
/*  '2;service name;1;0;1;1;0;0;1;1'  */
function service_index(cfg)
{
	if (cfg){
		return config_item(cfg, 0);
	}
	return config_default_value; 			
}

function service_name(cfg)
{
	if (cfg){
		return config_item(cfg, 1);
	}
	return config_default_value; 			
}

function service_matching_value(cfg)
{
	if (cfg){
		return config_item(cfg, 2);
	}
	return config_default_value; 			
}

function service_priority(cfg)
{
	if (cfg){
		return config_item(cfg, 3);
	}
	return config_default_value; 		
}

function service_down_cir(cfg)
{
	if (cfg){
		return config_item(cfg, 4);
	}
	return config_default_value; 
}

function service_up_cir(cfg)
{
	if (cfg){
		return config_item(cfg, 5);
	}
	return config_default_value; 		
}

function service_down_pir(cfg)
{
	if (cfg){
		return config_item(cfg, 6);
	}
	return config_default_value; 
}

function service_up_pir(cfg)
{
	if (cfg){
		return config_item(cfg, 7);
	}
	return config_default_value; 
}

function service_latency(cfg)
{
	if (cfg){
		return config_item(cfg, 8);
	}
	return config_default_value; 		
}


/*white_list*/
function white_index(cfg)
{
	 return ( cfg ? config_item(cfg,0) : config_default_value );
}

function white_mac(cfg)
{
	return ( cfg ? (config_item(cfg,1).toUpperCase()) : config_default_value );
}
function white_auth(cfg)
{
	return ( cfg ? config_item(cfg,2) : config_default_value );
}

function white_igmp(cfg)
{
	return ( cfg ? config_item(cfg,3) : config_default_value );
}

function white_down_pir(cfg)
{
	return ( cfg ? config_item(cfg,4) : config_default_value );
}

function white_up_pir(cfg)
{
	return ( cfg ? config_item(cfg,5) : config_default_value );
}
function white_maclimit(cfg)
{
	return ( cfg ? config_item(cfg,6) : config_default_value );
}

function white_outlevel(cfg)
{
	return ( cfg ? config_item(cfg,7) : config_default_value );
}

function white_autoupgrade(cfg)
{
	return ( cfg ? config_item(cfg,8) : config_default_value );
}

function white_admin_status(cfg)
{
	return ( cfg ? config_item(cfg,9) : config_default_value );
}

function white_upgrade_file(cfg)
{
	return ( cfg ? config_item(cfg,10) : config_default_value );
}

function white_upgrade_type(cfg)
{
	return ( cfg ? config_item(cfg,11) : config_default_value );
}

function white_loop_detect(cfg)
{
	return ( cfg ? config_item(cfg,12) : config_default_value );
}

function white_sc_port_mirror_type(cfg)
{
	return ( cfg ? config_item(cfg,13) : config_default_value );
}

function white_sc_port_mirror_enable(cfg)
{
	return ( cfg ? config_item(cfg,14) : config_default_value );
}

function white_sc_port_mirror_source(cfg)
{
	return ( cfg ? config_item(cfg,15) : config_default_value );
}

function white_sc_port_mirror_dest(cfg)
{
	return ( cfg ? config_item(cfg,16) : config_default_value );
}

function white_sc_loop_detect_enable(cfg)
{
	return ( cfg ? config_item(cfg,17) : config_default_value );
}

function white_sc_flow_control(cfg)
{
	return ( cfg ? config_item(cfg,18) : config_default_value );
}

function white_sc_aging_time(cfg)
{
	return ( cfg ? config_item(cfg,19) : config_default_value );
}

function white_tmplid(cfg)
{
	return ( cfg ? config_item(cfg,20) : config_default_value );
}


function wport_index(cfg)
{
	return ( cfg ? config_item(cfg,0) : config_default_value );
}

function wport_enable(cfg)
{
	return ( cfg ? config_item(cfg,1) : config_default_value );
}

function wport_mode(cfg)
{
	return ( cfg ? config_item(cfg,2) : config_default_value );
}

function wport_pvid(cfg)
{
	return ( cfg ? config_item(cfg,3) : config_default_value );
}

function wport_tpid(cfg)
{
	return ( cfg ? config_item(cfg,4) : config_default_value );
}

function wport_priority(cfg)
{
	return ( cfg ? config_item(cfg,5) : config_default_value );
}

function wport_vlanmode(cfg)
{
	return ( cfg ? config_item(cfg,6) : config_default_value );
}

function wport_vlanids(cfg)
{
	return ( cfg ? config_item(cfg,7) : config_default_value );
}

function wport_bcast_en(cfg)
{
	return ( cfg ? config_item(cfg,8) : config_default_value );
}

function wport_bcast(cfg)
{
	return ( cfg ? config_item(cfg,9) : config_default_value );
}

function wport_mcast_en(cfg)
{
	return ( cfg ? config_item(cfg,10) : config_default_value );
}

function wport_mcast(cfg)
{
	return ( cfg ? config_item(cfg,11) : config_default_value );
}

function wport_ucast_en(cfg)
{
	return ( cfg ? config_item(cfg,12) : config_default_value );
}

function wport_ucast(cfg)
{
	return ( cfg ? config_item(cfg,13) : config_default_value );
}

function wport_service(cfg)
{
	return ( cfg ? config_item(cfg,14) : config_default_value );
}

function wport_flowctrl(cfg)
{
	return ( cfg ? config_item(cfg,15) : config_default_value );
}

function wport_vlanpool(cfg)
{
	return ( cfg ? config_item(cfg,16) : config_default_value );
}

function wport_vlanpool_pvid(cfg)
{
	return ( cfg ? config_item(cfg,17) : config_default_value );
}

/*	End port_list	*/

/*	var vlanpool_list = new Array('1;China;1;0;10;6;1;4094,5,87');	*/
/* index ; name ; enable ; flag ; count ; available ; prio ; vlan */

function vlanpool_index(cfg)
{
	return ( cfg ? config_item(cfg,0) : config_default_value );
}

function vlanpool_name(cfg)
{
	return ( cfg ? config_item(cfg,1) : config_defalut_value );
}

function vlanpool_enable(cfg)
{
	return ( cfg ? config_item(cfg,2) : config_defalut_value );
}

function vlanpool_flag(cfg)
{
	return ( cfg ? config_item(cfg,3) : config_defalut_value );
}

function vlanpool_count(cfg)
{
	return ( cfg ? config_item(cfg,4) : config_defalut_value );
}

function vlanpool_available(cfg)
{
	return ( cfg ? config_item(cfg,5) : config_defalut_value );
}

function vlanpool_priority(cfg)
{
	return ( cfg ? config_item(cfg,6) : config_defalut_value );
}

function vlanpool_vlans(cfg)
{
	return ( cfg ? config_item(cfg,7) : config_defalut_value );
}

/* user model */
/* devid, chipid, tmplid, lswid, extoption, model, portnum, portmap, portname, hfid */
function usermodel_index(cfg)
{
	return ( cfg ? config_item(cfg,0) : config_default_value );
}

function usermodel_chipid(cfg)
{
	return ( cfg ? config_item(cfg,1) : config_defalut_value );
}

function usermodel_tmplid(cfg)
{
	return ( cfg ? config_item(cfg,2) : config_defalut_value );
}

function usermodel_lswid(cfg)
{
	return ( cfg ? config_item(cfg,3) : config_defalut_value );
}

function usermodel_extopt(cfg)
{
	return ( cfg ? config_item(cfg,4) : config_defalut_value );
}

function usermodel_opt_match_first_hfid(cfg)
{
	var v32 = parseInt(usermodel_extopt(cfg), 10);
	return (v32 & 0x01) ? true : false;
}

function usermodel_opt_show_first_hfid(cfg)
{
	var v32 = parseInt(usermodel_extopt(cfg), 10);
	return (v32 & 0x02) ? true : false;
}

function usermodel_name(cfg)
{
	return ( cfg ? config_item(cfg,5) : config_defalut_value );
}

function usermodel_portnum(cfg)
{
	return ( cfg ? config_item(cfg,6) : config_defalut_value );
}

function usermodel_portmap(cfg)
{
	var a = ( cfg ? config_item(cfg,7) : config_defalut_value );
	return a.split(',');	
}

function usermodel_portname(cfg)
{
	var a = ( cfg ? config_item(cfg,8) : config_defalut_value );
	return a.split(',');	
}

function usermodel_hfid(cfg)
{
	return ( cfg ? config_item(cfg,9) : config_defalut_value );
}


/*
 * hc template
 * 
 * */
 
/*
 *  enable;max_num;created_num;next_free_index;whitelist_index
 * 
 * */

function hc_tmpl_global_enable(cfg)
{	
	if (cfg){
		return config_item(cfg, 0);
	}
	return 0; 		
}

function hc_tmpl_max_num(cfg)
{	
	if (cfg){
		return config_item(cfg, 1);
	}
	return 0; 		
}

function hc_tmpl_num(cfg)
{	
	if (cfg){
		return config_item(cfg, 2);
	}
	return 0; 		
}

function hc_tmpl_white_id(cfg)
{	
	if (cfg){
		return config_item(cfg, 4);
	}
	return 0; 		
}

/*
 *  id;enable;name;desc
 * 
 * */

function hc_tmpl_id(cfg)
{	
	if (cfg){
		return config_item(cfg, 0);
	}
	return 0; 		
}

function hc_tmpl_enable(cfg)
{	
	if (cfg){
		return config_item(cfg, 1);
	}
	return 0; 		
}

function hc_tmpl_name(cfg)
{	
	if (cfg){
		return config_item(cfg, 2);
	}
	return 0; 		
}

function hc_tmpl_desc(cfg)
{	
	if (cfg){
		return config_item(cfg, 3);
	}
	return 0; 		
}


/*
 *  hc template extented options
 * */

function hc_tmpl_serviceid(cfg)
{
	if (cfg){
		return config_item(cfg, 10);
	}
	return config_default_value; 			
}

function hc_tmpl_vlanpoolid(cfg)
{
	if (cfg){
		return config_item(cfg, 11);
	}
	return config_default_value; 			
}


function hc_tmpl_vlanmode(cfg)
{
	if (cfg){
		return config_item(cfg, 12);
	}
	return config_default_value; 			
}


function hc_tmpl_taggedvlan(cfg)
{
	if (cfg){
		return config_item(cfg, 13);
	}
	return config_default_value; 			
}


function hc_tmpl_untaggedvlan(cfg)
{
	if (cfg){
		return config_item(cfg, 14);
	}
	return config_default_value; 			
}


function hc_tmpl_search(list, filter)
{
	var show=new Array();
	var re=/^\s*$/;
	var fact=filter.toUpperCase();
	if (re.test(filter)) return list;
	for (var i=0; i < list.length; i ++){
		var m = hc_tmpl_id(list[i]);
		if (m == fact){
			show[show.length] = list[i];
			continue;			
		}
		
		m = hc_tmpl_name(list[i]).toUpperCase();
		if (m.indexOf(fact) != -1){
			show[show.length] = list[i];
			continue;
		}
		m = hc_tmpl_desc(list[i]).toUpperCase();
		if (m.indexOf(fact) != -1){
			show[show.length] = list[i];
			continue;
		}
	}
	return show;	
}

